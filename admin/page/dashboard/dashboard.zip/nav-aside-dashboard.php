<li class="nav-item">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-tachometer-alt"></i>
        <p>
            Dashboard
            <i class="right fas fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="page.php?mod=user" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>User</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="page.php?mod=data-user" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Data User</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="page.php?mod=carousel" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Carousel Utama</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="page.php?mod=carousel-menu" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Carousel Menu</p>
            </a>
        </li>
    </ul>
</li>