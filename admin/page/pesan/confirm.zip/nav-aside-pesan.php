                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                <i class="nav-icon fas fa-edit"></i>
                                <p>
                                    Pesan
                                    <i class="fas fa-angle-left right"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="page.php?mod=pesan" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Data pesanan</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="page.php?mod=konfirmasi-pesan" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Pesanan Berhasil</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="page.php?mod=keranjang" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Keranjang</p>
                                    </a>
                                </li>
                            </ul>
                        </li>